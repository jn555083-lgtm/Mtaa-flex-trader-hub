import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import "./styles.css";

type Tick = { epoch: number; quote: number };

const SYMBOLS = [
  ["1HZ100V", "Volatility 100 (1s)"],
  ["1HZ50V", "Volatility 50 (1s)"],
  ["1HZ75V", "Volatility 75 (1s)"],
  ["1HZ25V", "Volatility 25 (1s)"],
  ["1HZ10V", "Volatility 10 (1s)"]
];

function useTicks(symbol: string) {
  const [ticks, setTicks] = useState<Tick[]>([]);
  const [status, setStatus] = useState("connecting");
  const ws = useRef<WebSocket | null>(null);

  useEffect(() => {
    setTicks([]);
    setStatus("connecting");
    const socket = new WebSocket("wss://api.derivws.com/trading/v1/options/ws/public");
    ws.current = socket;

    socket.onopen = () => {
      setStatus("live");
      socket.send(JSON.stringify({
        ticks: symbol,
        subscribe: 1,
        req_id: 1
      }));
    };
    socket.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);
        if (msg.tick?.quote !== undefined) {
          setTicks(prev => [...prev.slice(-119), {
            epoch: Number(msg.tick.epoch),
            quote: Number(msg.tick.quote)
          }]);
        }
      } catch {}
    };
    socket.onerror = () => setStatus("error");
    socket.onclose = () => setStatus("offline");

    return () => socket.close();
  }, [symbol]);

  return { ticks, status };
}

function Sparkline({ ticks }: { ticks: Tick[] }) {
  const points = useMemo(() => {
    if (!ticks.length) return "";
    const values = ticks.map(t => t.quote);
    const min = Math.min(...values), max = Math.max(...values);
    const range = max - min || 1;
    return values.map((v, i) => {
      const x = (i / Math.max(values.length - 1, 1)) * 100;
      const y = 90 - ((v - min) / range) * 75;
      return `${x},${y}`;
    }).join(" ");
  }, [ticks]);

  return <svg className="chart" viewBox="0 0 100 100" preserveAspectRatio="none">
    <polyline points={points} fill="none" stroke="currentColor" strokeWidth="1.8" vectorEffect="non-scaling-stroke"/>
  </svg>;
}

function App() {
  const [symbol, setSymbol] = useState(SYMBOLS[0][0]);
  const [tab, setTab] = useState("Terminal");
  const { ticks, status } = useTicks(symbol);

  const latest = ticks[ticks.length - 1]?.quote ?? 0;
  const lastDigit = latest ? Number(String(latest).replace(".", "").slice(-1)) : null;
  const digitCounts = Array.from({ length: 10 }, (_, d) => ticks.filter(t => Number(String(t.quote).replace(".", "").slice(-1)) === d).length);
  const total = Math.max(ticks.length, 1);

  const even = digitCounts.reduce((s, n, d) => s + (d % 2 === 0 ? n : 0), 0) / total * 100;
  const odd = 100 - even;

  return <div className="app">
    <header>
      <div>
        <div className="brand">MtaaFlex <span>TRADER HUB</span></div>
        <div className="sub">Deriv analytics • bots • community</div>
      </div>
      <a className="connect" href="/api/auth/deriv/start">Connect Deriv</a>
    </header>

    <nav>
      {["Terminal", "Scanner", "Bots", "Community", "Wallet", "Admin"].map(x =>
        <button className={tab === x ? "active" : ""} onClick={() => setTab(x)} key={x}>{x}</button>
      )}
    </nav>

    {tab === "Terminal" && <main className="grid">
      <section className="panel hero">
        <div className="row">
          <select value={symbol} onChange={e => setSymbol(e.target.value)}>
            {SYMBOLS.map(([id, name]) => <option value={id} key={id}>{name}</option>)}
          </select>
          <span className={`status ${status}`}>● {status}</span>
        </div>
        <div className="price">{latest ? latest.toFixed(2) : "—"}</div>
        <div className="muted">Live tick • Last digit: <b>{lastDigit ?? "—"}</b></div>
        <Sparkline ticks={ticks}/>
      </section>

      <section className="panel">
        <h3>Even / Odd scanner</h3>
        <div className="split">
          <div><strong>{even.toFixed(1)}%</strong><span>EVEN</span></div>
          <div><strong>{odd.toFixed(1)}%</strong><span>ODD</span></div>
        </div>
        <div className="meter"><i style={{width: `${even}%`}}/></div>
        <p className="muted">Rolling frequency from the latest live ticks. It is not a guaranteed prediction.</p>
      </section>

      <section className="panel wide">
        <h3>Digit distribution</h3>
        <div className="digits">
          {digitCounts.map((n, d) => <div key={d}><b>{d}</b><span>{(n/total*100).toFixed(1)}%</span><i style={{height: `${Math.max(5,n/total*100*2)}%`}}/></div>)}
        </div>
      </section>

      <section className="panel wide">
        <h3>Trading controls</h3>
        <div className="controls">
          {["Even/Odd", "Over/Under", "Rise/Fall", "Matches/Differs"].map(x => <button key={x}>{x}</button>)}
        </div>
        <div className="warning">Real-money execution is locked until Deriv OAuth, server-side sessions, risk controls and production configuration are completed.</div>
      </section>
    </main>}

    {tab === "Scanner" && <Page title="AI Market Scanner" cards={[
      ["LIVE TICKS", "Connected to Deriv public market data"],
      ["EVEN / ODD", "Rolling digit-frequency analysis"],
      ["OVER / UNDER", "Digit threshold analysis module"],
      ["RISK ENGINE", "Stake, stop-loss and take-profit guards"]
    ]}/>}
    {tab === "Bots" && <Page title="Bot Marketplace" cards={[
      ["Digit Scanner Bot", "Even/Odd statistical scanner"],
      ["Under Scanner", "Rolling threshold scanner"],
      ["Risk Guard", "Stops trading after configured limits"],
      ["Custom Bot", "Build strategies around approved rules"]
    ]}/>}
    {tab === "Community" && <Page title="MtaaFlex Community" cards={[
      ["Signals", "Share market observations"],
      ["Bot discussions", "Discuss strategy performance"],
      ["Leaderboard", "Performance metrics can be added after verified trade history"],
      ["Moderation", "Admin moderation and audit APIs included"]
    ]}/>}
    {tab === "Wallet" && <Page title="Wallet & Accounts" cards={[
      ["Deriv account", "Connect using OAuth"],
      ["Balance", "Sync from authenticated account"],
      ["Deposit / withdrawal", "Requires the appropriate Deriv/payment-agent architecture and approvals"],
      ["Security", "Tokens belong on the server, never in browser storage"]
    ]}/>}
    {tab === "Admin" && <Page title="Admin Console" cards={[
      ["Users", "User and account management"],
      ["Bots", "Review and disable bots"],
      ["Risk", "Global safety limits"],
      ["Audit logs", "Track sensitive actions"]
    ]}/>}
  </div>;
}

function Page({ title, cards }: { title: string; cards: string[][] }) {
  return <main className="grid"><section className="panel wide"><h2>{title}</h2></section>{cards.map(([a,b]) =>
    <section className="panel" key={a}><h3>{a}</h3><p className="muted">{b}</p></section>
  )}</main>;
}

createRoot(document.getElementById("root")!).render(<React.StrictMode><App/></React.StrictMode>);
